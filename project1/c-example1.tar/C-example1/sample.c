   int result
